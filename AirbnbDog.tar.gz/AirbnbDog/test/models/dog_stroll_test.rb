require 'test_helper'

class DogStrollTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
